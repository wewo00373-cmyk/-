# НейроПес — AI Тамагочі (Android)

Android-обгортка (WebView) навколо гри neuropet.html. Гра повністю офлайн,
прогрес зберігається через localStorage.

## Варіант 1. Збірка APK без встановлення нічого (рекомендовано)

1. Створіть репозиторій на GitHub і завантажте туди вміст цього архіву
   (кнопка "Add file" → "Upload files", або через `git push`).
2. Відкрийте вкладку **Actions** → запустіть workflow **Build APK**
   (або він запуститься сам після пушу).
3. Через ~3 хвилини в тому ж розділі Actions у завершеному запуску буде
   артефакт `neuropet-apk` — завантажте та розпакуйте його: всередині `app-debug.apk`.
4. Скопіюйте APK на телефон, встановіть (дозвольте "встановлення з невідомих джерел").
   Це debug-підписаний додаток — Android попередить, що розробник невідомий, це нормально.

## Варіант 2. Через Android Studio

1. Розпакуйте архів.
2. Android Studio → Open → оберіть цю папку.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK буде в `app/build/outputs/apk/debug/`.

## Варіант 3. Локально з терміналом

Потрібні JDK 17+, Android SDK (змінна ANDROID_HOME) та Gradle 8.7+:

```
gradle assembleDebug
```

## Кастомізація

- Назва додатка: `app/src/main/res/values/strings.xml`
- Іконка: замініть `android:icon` в `AndroidManifest.xml` на свій міпмап
- Версія: `versionCode` / `versionName` в `app/build.gradle`
- Логіка гри: `app/src/main/assets/www/neuropet.html` (звичайний HTML/JS)
